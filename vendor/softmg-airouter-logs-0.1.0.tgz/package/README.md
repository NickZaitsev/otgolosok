# @softmg/airouter-logs

Private Node.js 18+ SDK for sending bounded, redacted error and warning events to Airouter. It batches events in memory, gzips requests, retries with exponential backoff and jitter, and preserves each batch idempotency key across retries. It does not patch `console`.

## Install

Configure a GitLab package token, then install from the private registry:

```sh
export NPM_TOKEN='<gitlab-package-token>'
npm install @softmg/airouter-logs
```

For CI publication, set `NPM_TOKEN` to a token with package write access and run `npm publish`. The package is configured for the `git.softmg.ru` instance-level npm endpoint with restricted access.

## Core usage

```ts
import { createAirouterLogger } from "@softmg/airouter-logs";

const logs = createAirouterLogger({
  endpoint: "https://airouter.example.com",
  token: process.env.AIROUTER_LOG_TOKEN!,
  service: "billing-api",
  environment: process.env.NODE_ENV ?? "development",
  release: process.env.APP_VERSION,
});

logs.captureMessage("Payment delayed", "warn", {
  requestId: "req_123",
  tags: { provider: "stripe" },
  context: { invoiceId: "inv_123" },
});

try {
  await chargeInvoice();
} catch (error) {
  logs.captureException(error, { operation: "chargeInvoice" });
}

await logs.flush();
await logs.close();
```

Events contain only `timestamp`, `level`, `message`, `stack`, `service`, `environment`, `release`, `requestId`, `traceId`, `operation`, `tags`, and `context`. Strings, collection sizes, recursion depth, event size, queue count, and queue bytes are bounded. Keys such as passwords, tokens, authorization headers, cookies, and API keys are recursively redacted; credential-like string values are redacted as well.

## Next.js route wrapper

```ts
import { withAirouterLogging } from "@softmg/airouter-logs/next";
import { logs } from "@/lib/logs";

export const GET = withAirouterLogging(logs, async (request) => {
  return Response.json({ ok: true });
}, { operation: "GET /api/status" });
```

The wrapper records request method, URL, request ID, and trace header, then rethrows the original error. It has no Next.js runtime dependency.

## Pino-like adapter

```ts
import { createPinoAdapter } from "@softmg/airouter-logs/pino";

const log = createPinoAdapter(logs).child({ component: "worker" });
log.warn({ jobId: 42 }, "Job delayed");
log.error(new Error("Job failed"), "Worker failed");
```

The adapter intentionally exposes only `error`, `warn`, `child`, `flush`, and `close`, matching the supported event levels without depending on Pino.

## Lifecycle and failures

Call `close()` during graceful shutdown (`SIGTERM`/`SIGINT`). Automatic interval flush failures are delivered to `onError`. An explicit `flush()` or `close()` rejects after retries are exhausted; the unsent batch remains in memory with the same key so a later flush can retry it. When queue limits are reached, oldest queued events are dropped and reported through `onDrop`.
